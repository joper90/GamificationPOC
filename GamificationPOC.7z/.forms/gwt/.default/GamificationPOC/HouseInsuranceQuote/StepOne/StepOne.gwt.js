

if (typeof(tibcoforms) == 'undefined') tibcoforms = new Object();
if (typeof(tibcoforms.formCode) == 'undefined') tibcoforms.formCode = new Object();
tibcoforms.formCode['_IIZ9QEiCEeOGG8vc3RqC5A'] = new Object();
tibcoforms.formCode['_IIZ9QEiCEeOGG8vc3RqC5A']['defineActions'] = function() {
var fc = tibcoforms.formCode['_IIZ9QEiCEeOGG8vc3RqC5A'];
	fc['rule_cancel'] = function(formId, context, thisObj) {
	   try {
    var form = tibcoforms.formCache[formId];
	var data = new tibcoforms.formCode[form.jsForm.formModelId]['DataModel'](formId);
	var pane = form.paneMap;
	var control = form.controlMap;
	var factory = form._factory;
	var pkg = form._package;
	var f = form.f;
	var p = form.p;
		try {
		fc['action_cancel'].call(thisObj, context, data, pane, control, factory, pkg, f , p);
		} catch(e) {
           tibcoforms.bridge.log_error("Rule(cancel) Action(cancel) Script Error: " + e);
           throw e;
        }
	   } catch(e) {
	       tibcoforms.bridge.log_error("Rule(cancel) Action Script Error: " + e);
	       throw e;
	   }
	}

	fc['rule_close'] = function(formId, context, thisObj) {
	   try {
    var form = tibcoforms.formCache[formId];
	var data = new tibcoforms.formCode[form.jsForm.formModelId]['DataModel'](formId);
	var pane = form.paneMap;
	var control = form.controlMap;
	var factory = form._factory;
	var pkg = form._package;
	var f = form.f;
	var p = form.p;
		try {
		fc['action_close'].call(thisObj, context, data, pane, control, factory, pkg, f , p);
		} catch(e) {
           tibcoforms.bridge.log_error("Rule(close) Action(close) Script Error: " + e);
           throw e;
        }
	   } catch(e) {
	       tibcoforms.bridge.log_error("Rule(close) Action Script Error: " + e);
	       throw e;
	   }
	}

	fc['rule_submit'] = function(formId, context, thisObj) {
	   try {
    var form = tibcoforms.formCache[formId];
	var data = new tibcoforms.formCode[form.jsForm.formModelId]['DataModel'](formId);
	var pane = form.paneMap;
	var control = form.controlMap;
	var factory = form._factory;
	var pkg = form._package;
	var f = form.f;
	var p = form.p;
		try {
		fc['action_submit'].call(thisObj, context, data, pane, control, factory, pkg, f , p);
		} catch(e) {
           tibcoforms.bridge.log_error("Rule(submit) Action(submit) Script Error: " + e);
           throw e;
        }
	   } catch(e) {
	       tibcoforms.bridge.log_error("Rule(submit) Action Script Error: " + e);
	       throw e;
	   }
	}

	fc['action_cancel'] = function(context, data, pane, control, factory, pkg, f , p) {
		context.form.invokeAction('cancel');
	}

	fc['action_apply'] = function(context, data, pane, control, factory, pkg, f , p) {
		context.form.invokeAction('apply');
	}
	
	fc['action_close'] = function(context, data, pane, control, factory, pkg, f , p) {
		context.form.invokeAction('close');
	}

	fc['action_submit'] = function(context, data, pane, control, factory, pkg, f , p) {
		context.form.invokeAction('submit');
	}
	
	fc['action_validate'] = function(context, data, pane, control, factory, pkg, f , p) {
		context.form.invokeAction('validate');
    }
    
    fc['action_reset'] = function(context, data, pane, control, factory, pkg, f , p) {
    	context.form.invokeAction('reset');
    }
    
    fc['generator_info'] = function() {
        return "TIBCO Forms 2.5.0 V21 Compliant";
    }
};
tibcoforms.formCode['_IIZ9QEiCEeOGG8vc3RqC5A']['defineActions']();

tibcoforms.formCode['_IIZ9QEiCEeOGG8vc3RqC5A']['defineValidations'] = function() {
var fc = tibcoforms.formCode['_IIZ9QEiCEeOGG8vc3RqC5A'];
	
	
	
	
	
	
fc['validation_TextField_TextField__length'] = function(formId, controlName, cloneUID, listIndex) {
	var context = new Object();
    var form = tibcoforms.formCache[formId];
	var logger = tibcoforms.bridge.log_logger();
	context.control = this;
    if (listIndex == -1) {
        context.value = context.control.getValue();
        if (context.control.getStringValue)
            context.stringValue = context.control.getStringValue();
    } else {
        context.value = context.control.getValue()[listIndex];
        if (context.control.getStringValue)
            context.stringValue = context.control.getStringValue()[listIndex];
    }
    if (context.value == null)
        context.value = '';
	var valScr = 'typeof context.stringValue != \'undefined\' && typeof tibco.forms.Util != \'undefined\' ? tibco.forms.Util.checkTextLength(context.stringValue, 50) ? true : [context.control.getLabel(), \'50\'] : context.value.length <= 50;';
	try {
	   return eval(valScr);
	} catch(e) {
	   tibcoforms.bridge.log_error("Validation(TextField: TextField__length) Script Error: " + e + ", for script: " + valScr);
	   throw e;
	}
}
	
	fc['validate_required'] = function(formId, controlName, cloneUID, listIndex) {
	var context = new Object();
    var form = tibcoforms.formCache[formId];
	var logger = tibcoforms.bridge.log_logger();
	context.control = this;
    if (listIndex == -1) {
        context.value = context.control.getValue();
        if (context.control.getStringValue)
            context.stringValue = context.control.getStringValue();
    } else {
        context.value = context.control.getValue()[listIndex];
        if (context.control.getStringValue)
            context.stringValue = context.control.getStringValue()[listIndex];
    }
    if (context.value == null)
        context.value = '';
		var controlType = context.control.getControlType();
		var strContxtControlValue = context.control.getValue();
	    if (listIndex >= 0) {
	       strContxtControlValue = strContxtControlValue[listIndex];
	    }
	    return !(context.control.getRequired() && 
                 (strContxtControlValue == null || strContxtControlValue.toString().length == 0) ||
                 (("com.tibco.forms.controls.checkbox" == controlType) && 'true' != strContxtControlValue.toString().toLowerCase()));
	}
	fc['register_pkgs_and_fcts'] = function(formId) {
	   var form = tibcoforms.formCache[formId];
	   form.registerPackages([]);
       form.registerFactories([]);
	}
	fc['DataModel']=function(formId) {
		this.form = tibcoforms.formCache[formId];
		this.getTextField = function(useInternal) {
			return this.form.dataMap['TextField'].getValue(useInternal);
		};
		this.setTextField = function(value) {
			return this.form.dataMap['TextField'].setValue(value);
		};
	}
	   
	   
	   
};
tibcoforms.formCode['_IIZ9QEiCEeOGG8vc3RqC5A']['defineValidations']();
