/**
 * DO NOT EDIT: This is an automatically generated file.
 * This provides an implementation of the package class com.example.gamificationpoc.GamificationpocPackage.
 */

com.tibco.data.Loader.classDefiner["com.example.gamificationpoc.GamificationpocPackage"] = function() {

/**
 * Constructor.
 */
var theClass = function() {
};

com.tibco.data.Loader.currentLoader.registerClass(theClass, "com.example.gamificationpoc.GamificationpocPackage");



};

com.tibco.data.Loader.classDefiner["com.example.gamificationpoc.GamificationpocPackage"]();
